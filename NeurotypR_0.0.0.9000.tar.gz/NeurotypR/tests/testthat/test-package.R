test_that("NeurotypR package loads correctly", {
  expect_true(requireNamespace("NeurotypR", quietly = TRUE))
})
